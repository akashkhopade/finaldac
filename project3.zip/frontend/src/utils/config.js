export const URLUSER = 'http://localhost:8080'
export const URLAUTH = 'http://localhost:9090'