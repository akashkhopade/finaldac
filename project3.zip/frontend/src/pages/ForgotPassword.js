const ForgotPassword = ()=> {
    return (
        <div>
            <h1>This is Forgot Password page</h1>
        </div>
    )
}

export default ForgotPassword