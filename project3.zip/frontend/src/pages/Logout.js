const Logout = ()=> {
    return (
        <div>
            
        </div>
    )
}

export default Logout