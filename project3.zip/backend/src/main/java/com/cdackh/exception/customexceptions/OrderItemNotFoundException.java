package com.cdackh.exception.customexceptions;

public class OrderItemNotFoundException extends RuntimeException{
    public OrderItemNotFoundException(String msg) {
        super(msg);
    }
}
