package com.cdackh.exception.customexceptions;

public class PasswordMismatchException extends RuntimeException{
    public PasswordMismatchException(String msg) {
        super(msg);
    }
}
