package com.cdackh.models.requestDto;

import lombok.Data;

@Data
public class UserCredentialDto {
    private String email;
    private String password;
}
