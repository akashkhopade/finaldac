package com.cdackh.services;

import com.cdackh.converter.ToSimpleUserInfoConverter;
import com.cdackh.entities.Address;
import com.cdackh.entities.OrderDetail;
import com.cdackh.entities.User;
import com.cdackh.models.requestDto.ResetPasswordDto;
import com.cdackh.models.requestDto.UserSignupDto;
import com.cdackh.models.responseDto.AddressDto;
import com.cdackh.models.responseDto.OrderDetailDto;

import java.util.List;

public interface IUserService {
	User getUserByName(String name);
	ToSimpleUserInfoConverter getUserById(Long id);
	User getUserByEmail(String email);
	User registerUser(UserSignupDto userSignupDto);
	List<ToSimpleUserInfoConverter> getAllUser();
	boolean deleteUserById(Long id);
	User getUserByToken();
	String resetPassword(ResetPasswordDto resetPasswordDto);
	ToSimpleUserInfoConverter getUserDetailsByToken();
	List<AddressDto> getAllAddressByUserId(Long userId);
	//List<OrderDetailDto> getOrderDetailByUserId(long userId);
}
