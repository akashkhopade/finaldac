package com.cdackh.services;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdackh.entities.Category;
import com.cdackh.entities.Product;
import com.cdackh.repository.ICategoryRepository;

@Transactional
@Service
public class CategoryServiceImpl {

	
	@Autowired
	private ICategoryRepository categoryDao;
	
	
	
}
