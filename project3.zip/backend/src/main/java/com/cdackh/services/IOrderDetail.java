package com.cdackh.services;

import java.util.List;

import com.cdackh.entities.OrderDetail;
import com.cdackh.entities.OrderItem;
import com.cdackh.models.responseDto.OrderDetailDto;
import com.cdackh.models.responseDto.OrderItemDto;

public interface IOrderDetail {
	List<OrderDetailDto> findAllOrderDetails();
	OrderDetailDto findOrderDetailByOrderId(long orderId);
	OrderDetailDto findOrderDetailByOrderNumber(long orderNumber);
	List<OrderDetailDto> findOrderDetailByOrderStatus(String orderStatus);
	OrderDetail saveOrderDetail(OrderDetail orderDetail);
	int deleteOrderDetailByOrderId(long orderId);
	
	List<OrderItemDto> findOrderItemByOrderId(long orderId);
	
	
	
	List<OrderDetailDto> getOrderDetailByUserId(long userId);
	int updateOrderStatusByOrderId(long orderId);
}
