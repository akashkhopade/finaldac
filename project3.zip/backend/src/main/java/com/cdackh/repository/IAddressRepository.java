package com.cdackh.repository;

import com.cdackh.entities.Address;
import com.cdackh.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IAddressRepository extends JpaRepository<Address, Long> {
    List<Address> findByUser(User user);
}
