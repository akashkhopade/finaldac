package com.cdackh;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.cdackh.entities.Feedback;
import com.cdackh.entities.OrderDetail;
import com.cdackh.entities.OrderItem;
import com.cdackh.entities.User;
import com.cdackh.models.responseDto.FeedbackDto;
import com.cdackh.repository.IFeedbackRepository;
import com.cdackh.repository.IOrderDetailRepository;
import com.cdackh.repository.IOrderItemRepository;
import com.cdackh.repository.IUserRepository;
import com.cdackh.services.OrderDetailServiceImpl;
import com.cdackh.services.ProductServiceImpl;
import com.cdackh.services.UserServiceImpl;

@SpringBootTest
class productServiceTests {
	@Autowired
	private ProductServiceImpl productService;
	
	@Transactional
	@Test
	void testfindAllFeedbackByProductId() {
		List<FeedbackDto> list = productService.findAllFeedbackByProductId(4);
		list.forEach(System.out::println);
	}
	
	@Transactional
	@Test
	void testfindAllCommentByProductId() {
		List<Object[]> list = productService.findAllCommentByProductId(4);
		list.forEach(arr -> System.out.println(arr[0] + " - " + arr[1]));
	}
	
	@Transactional
	@Test
	void testfindAllRatingByProductId() {
		List<Object[]> list = productService.findAllRatingByProductId(4);
		list.forEach(arr -> System.out.println(arr[0]));
	}
	
//	public List<Feedback> findAllFeedbackByProductId(int id){
//		return productDao.findById(id).getFeedbackList();
//	}
}
