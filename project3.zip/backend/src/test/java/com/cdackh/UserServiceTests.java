package com.cdackh;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import com.cdackh.entities.Address;
import com.cdackh.models.responseDto.AddressDto;
import com.cdackh.repository.IAddressRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.cdackh.entities.OrderDetail;
import com.cdackh.entities.OrderItem;
import com.cdackh.entities.User;
import com.cdackh.models.responseDto.OrderDetailDto;
import com.cdackh.repository.IOrderDetailRepository;
import com.cdackh.repository.IOrderItemRepository;
import com.cdackh.repository.IUserRepository;
import com.cdackh.services.OrderDetailServiceImpl;
import com.cdackh.services.UserServiceImpl;

@SpringBootTest
class UserServiceTests {
    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private IAddressRepository address;

    @Transactional
    @Test
    void testListAllAddress() {
//        List<Address> list = address.findByUser(new User(10L));
        List<AddressDto> list = userService.getAllAddressByUserId(10L);
        list.forEach(System.out::println);
    }

//	@Transactional
//	@Test
//	void testGetOrderDetailByUserId() {
//		List<OrderDetailDto> list = userService.getOrderDetailByUserId(9);
//		list.forEach(System.out::println);
//	}


}
