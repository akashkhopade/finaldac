package com.cdackh;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.cdackh.entities.Feedback;
import com.cdackh.entities.OrderDetail;
import com.cdackh.entities.OrderItem;
import com.cdackh.entities.User;
import com.cdackh.repository.IFeedbackRepository;
import com.cdackh.repository.IOrderDetailRepository;
import com.cdackh.repository.IOrderItemRepository;
import com.cdackh.repository.IUserRepository;
import com.cdackh.repository.IProductRepository;
import com.cdackh.services.OrderDetailServiceImpl;
import com.cdackh.services.ProductServiceImpl;
import com.cdackh.services.UserServiceImpl;

@SpringBootTest
class productRepositoryTests {
	@Autowired
	private IProductRepository product;
	
	@Transactional
	@Test
	void testgetAvgRatingByProductId(){
		double result = product.getAvgRatingByProductId(4);
		System.out.println(result);
	}
	
	@Transactional
	@Test
	void testgetSumOfRatingByProductId(){
		int result = product.getSumOfRatingByProductId(4);
		System.out.println(result);
	}
}
