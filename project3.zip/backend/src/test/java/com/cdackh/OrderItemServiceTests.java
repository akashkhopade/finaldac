package com.cdackh;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.cdackh.entities.OrderDetail;
import com.cdackh.entities.OrderItem;
import com.cdackh.entities.User;
import com.cdackh.models.responseDto.OrderItemDto;
import com.cdackh.repository.IOrderDetailRepository;
import com.cdackh.repository.IOrderItemRepository;
import com.cdackh.repository.IUserRepository;
import com.cdackh.services.OrderDetailServiceImpl;

@SpringBootTest
class OrderItemServiceTests {
	@Autowired
	private OrderDetailServiceImpl orderDetail;
	
	@Transactional
	@Test
	void testfindOrderItemByOrderId() {
		List<OrderItemDto> list = orderDetail.findOrderItemByOrderId(2);
		list.forEach(System.out::println);
	}

	
	
	
}
